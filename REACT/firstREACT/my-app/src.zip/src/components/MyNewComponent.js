import React, { Component } from 'react';
import BirthdayButton  from './BirthdayButton';

class PersonCard extends React.Component{
    constructor(props) {
      super(props);
      this.state = {
          position:  this.props.age 
      };
  }
    switch = () => {
      var age = this.state.position
      age++;
      this.setState ( {
        position:  age 
    });
    }
    render () {
        const { firstName, lastName, age, hairColor} = this.props;
        return (
          <div>
              <h1>{ lastName }, { firstName } </h1>
              <h4>Age: {this.state.position}</h4>
              <h4>Hair Color: {hairColor}</h4>
              <button onClick={ this.switch }>Birthday Button for { this.props.firstName } { this.props.lastName } </button>
          </div>
        );
    }
}
export default PersonCard

